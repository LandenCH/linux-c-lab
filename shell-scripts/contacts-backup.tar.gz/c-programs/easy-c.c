#include <stdio.h>

int main() {
    int num = 5;
    int age;

    printf("Hello, C!\n");
    printf("Number: %d\n", num);

    printf("Enter your age: ");
    scanf("%d", &age);

    printf("Age: %d\n", age);

    return 0;
}

